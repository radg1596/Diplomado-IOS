//
//  MusicAlamo.swift
//  LabTunes
//
//  Created by Ricardo Desiderio on 11/14/18.
//  Copyright © 2018 Ricardo_Abraham_Desiderio_Diplomado. All rights reserved.
//

import Foundation
import Alamofire

class MusicAlamo {
    
    static func getSogs(with string: String, completion: @escaping ([Song]?) -> Void ) {
    request("https://itunes.apple.com/search?media=music&entity=song&term="+string)
            .validate()
            .responseJSON { (response) in
                guard response.result.isSuccess else {
                    completion(nil)
                    return
                }
                guard let resultDictionary = response.result.value as? NSDictionary else {return}
                let songsDictionary = resultDictionary["results"] as! [NSDictionary]
                let songs = songsDictionary.map( {Song.create(dict: $0)}) as! [Song]
                completion(songs)
            }
    }
    
}

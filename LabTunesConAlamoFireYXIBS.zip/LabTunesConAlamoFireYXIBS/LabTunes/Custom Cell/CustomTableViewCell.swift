//
//  CustomTableViewCell.swift
//  LabTunes
//
//  Created by Ricardo Desiderio on 11/14/18.
//  Copyright © 2018 Ricardo_Abraham_Desiderio_Diplomado. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var artistTextLabel: UILabel!
    @IBOutlet weak var songNameTextLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configure(with song: Song) {
        artistTextLabel.text = song.artist
        songNameTextLabel.text = song.name
    }
    
}
